<!DOCTYPE html>
<html lang="en">

<!-- ======= Head ======= -->
<?= $this->include('_partials/head') ?>
<!-- ======= End Head ======= -->

<body>

  <!-- ======= Header ======= -->
  <?= $this->include('_partials/header_diagnosis') ?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Diagnosis Section ======= -->
    <section id="diagnosis" class="contact">
      <div class="rt-container">
        <div class="col-rt-12">
          <div class="Scriptcontent">

            <!-- DEMO CONTENT -->
            <!-- partial:index.partial.html -->
            <link
              href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,700i,900,900i&amp;subset=latin-ext"
              rel="stylesheet">

            <div class="wrapper">
              <table class="table-scores">
                <thead>
                  <tr>
                    <th>
                      <div class="label">Gejala</div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($gejala as $data): ?>
                    <tr>
                      <td>
                        <div class="label"><?= $data['gejala'] ?></div>
                      </td>
                    </tr>
                  <?php endforeach ?>
                </tbody>
              </table>
              <div class="table-data-wrapper">
                <table class="table-data">
                  <thead>
                    <tr>
                      <th class="nowrap">
                        <div class="label">Input Gejala</div>
                        <div class="date">Ceklis Gejala</div>
                      </th>
                      <?php foreach($penyakit as $data): ?>
                        <th class="nowrap">
                          <div class="label"><?= $data['penyakit'] ?></div>
                          <div class="date">Bergejala</div>
                        </th>
                      <?php endforeach ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach($gejala as $gj): ?>
                      <tr>
                        <td style="pointer-events: auto;">
                          <div class="score-check">
                            <?php
                              if($gj['level']=='1'){
                                echo '<input class="form-check-input levelup" id="'.$gj['id'].'" type="checkbox" value="'.$gj['id'].'" id="flexCheckDefault">';
                              }
                              else {
                                echo '<input class="form-check-input levelup" id="'.$gj['id'].'" type="checkbox" value="'.$gj['id'].'" id="flexCheckDisabled" disabled>';
                              }
                            ?>
                          </div>
                        </td>
                        <?php foreach($penyakit as $py): ?>
                          <td>
                            <div class="score-check">
                              <?php 
                                for($i=0; $i<count($py['gejala_penyakit']); $i++){
                                  if($gj['id']==$py['gejala_penyakit'][$i]){
                                    echo '<i class="bx bxs-check-circle"></i>';
                                    break;
                                  }
                                  if($i==(count($py['gejala_penyakit'])-1)){
                                    echo '-';
                                  }
                                }
                              ?>
                            </div>
                          </td>
                        <?php endforeach ?>
                      </tr>
                    <?php endforeach ?>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- partial -->

          </div>
        </div>
      </div>
	  </section>
    <!-- End Diagnosis Section -->

    <footer id="footer" style="background: white;">
      <div class="footer-newsletter">
          <div class="container" id="hasil_diagnosis">
              <div class="row justify-content-center">
                  <div class="col-lg-6">
                      <h4>Diagnosis</h4>
                      <p>Masukkan nama anda</p>
                      <form action="" method="post">
                          <input type="text" name="nama"><input id="submit" type="button" value="Submit">
                      </form>
                  </div>
              </div>
          </div>
      </div> 
    </footer>

  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  <?= $this->include('_partials/footer') ?>
  <!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <?= $this->include('_partials/js') ?>
  <?= $this->include('_partials/diagnosa') ?>

</body>

</html>