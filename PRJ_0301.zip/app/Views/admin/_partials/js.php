    <!-- jQuery -->
    <script src="<?= base_url('modules/admin/vendors/jquery/dist/jquery.min.js') ?>"></script>
    <!-- Bootstrap -->
    <script src="<?= base_url('modules/admin/vendors/bootstrap/dist/js/bootstrap.bundle.min.js') ?>"></script>

    <!-- iCheck -->
    <script src="<?= base_url('modules/admin/vendors/iCheck/icheck.min.js') ?>"></script>
    <!-- dibutuhkan untuk custom check input -->
    
    <!-- NProgress -->
    <script src="<?= base_url('modules/admin/vendors/nprogress/nprogress.js') ?>"></script>

    <!-- Switchery -->
    <script src="<?= base_url('modules/admin/vendors/switchery/dist/switchery.min.js') ?>"></script> 
    <!-- dibutuhkan untuk custom switch input-->

    <!-- Editor Text -->
    <script type="text/javascript" src="<?php echo base_url('modules/admin/vendors/ckeditor/ckeditor.js') ?>"></script>

    <!-- jquery.inputmask -->
    <script src="<?php echo base_url('modules/admin/vendors/jquery.inputmask/dist/min/jquery.inputmask.bundle.min.js') ?>"></script>
    <!-- dibutuhkan untuk masking input -->

    <script src="<?= base_url('modules/admin/vendors/datatables.net/js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?= base_url('modules/admin/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js') ?>"></script>
        
    <!-- Custom Theme Scripts -->
    <script src="<?= base_url('modules/admin/js/custom.js') ?>"></script>