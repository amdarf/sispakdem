                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                        <div class="menu_section">
                            <h3>Data Management</h3>
                            <ul class="nav side-menu">
                                <li><a href="<?= site_url('admin/penyakit') ?>"><i class="fa fa-bug"></i> Penyakit </a></li>
                                <li><a href="<?= site_url('admin/pencegahan') ?>"><i class="fa fa-files-o"></i> Pencegahan </a></li>
                                <li><a href="<?= site_url('admin/gejala') ?>"><i class="fa fa-balance-scale"></i> Gejala </a></li>
                                <li><a href="<?= site_url('admin/kategori') ?>"><i class="fa fa-archive"></i> Kategori </a></li>
                                <li><a href="<?= site_url('admin/riwayat') ?>"><i class="fa fa-history"></i> Riwayat </a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- /menu footer buttons -->
                    <div class="sidebar-footer hidden-small">
                        <a data-toggle="tooltip" data-placement="top" title="Settings">
                            <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="Logout">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                        </a>
                    </div>
                    <!-- /menu footer buttons -->