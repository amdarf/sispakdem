            <footer>
                <div class="pull-right">
                    &copy; Copyright <strong><span><?= SITE_NAME2 ?> </span></strong>. All Rights Reserved
                </div>
                <div class="clearfix"></div>
            </footer>