<!-- Delete Confirmation-->
<div class="modal fade bd-example-modal-xl" id="reqruitment" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <!-- <h5 style="color:red;" class="modal-title">Reqruitment</h5> -->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <a href="https://wa.me/<?= "+62"."82296253749" ?>"><img style="width:100%;" src="<?= base_url('modules/img/hiring.png') ?>" alt="hiring"></a>
            </div>
        </div>
    </div>
</div>