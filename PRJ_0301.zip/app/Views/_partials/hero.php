<section id="hero" class="d-flex align-items-center">
    <div class="container" data-aos="zoom-out" data-aos-delay="100">
        <h1>Welcome to <span><?=SITE_NAME2?></span></h1>
        <h2>Sistem Pakar Demam, melakukan diagnosis awal terhadap gejala gejala penyakit dengan Demam</h2>
        <div class="d-flex">
            <a href="<?= site_url('diagnosis') ?>" class="btn-get-started scrollto">Get Started</a>
        </div>
    </div>
</section>