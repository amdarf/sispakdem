<!-- jQuery -->
<script src="<?= base_url('modules/admin/vendors/jquery/dist/jquery.min.js') ?>"></script>

<script src="<?= base_url('modules/vendor/purecounter/purecounter_vanilla.js') ?>"></script>
<script src="<?= base_url('modules/vendor/aos/aos.js') ?>"></script>
<script src="<?= base_url('modules/vendor/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= base_url('modules/vendor/glightbox/js/glightbox.min.js') ?>"></script>
<script src="<?= base_url('modules/vendor/isotope-layout/isotope.pkgd.min.js') ?>"></script>
<script src="<?= base_url('modules/vendor/swiper/swiper-bundle.min.js') ?>"></script>
<script src="<?= base_url('modules/vendor/waypoints/noframework.waypoints.js') ?>"></script>
<script src="<?= base_url('modules/vendor/php-email-form/validate.js') ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Template Main JS File -->
<script src="<?= base_url('modules/js/main.js') ?>"></script>